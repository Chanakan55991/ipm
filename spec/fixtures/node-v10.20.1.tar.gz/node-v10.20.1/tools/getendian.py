from __future__ import print_function
import sys
# "little" or "big"
print(sys.byteorder)
